import argparse
import copy
import json
import os
from os.path import join
import numpy as np
from tqdm import tqdm
from random import shuffle
import torch
import get_output
from model_data_prepare import prepare
from evaluate_fid import evaluate_multiple_models
from attgan.data import check_attribute_conflict
import torch.nn.functional as TFunction
import setGPU


do_end_to_end = True
do_feature_ensemble = True
do_grad_ensemble = True

do_output_ensemble = False
do_loss_ensemble = False

batch_evaluate = True


def parse(args=None):
    with open(join('./setting.json'), 'r') as f:
        args_attack = json.load(f, object_hook=lambda d: argparse.Namespace(**d))
    return args_attack


# Init the attacker
def init_get_outputs(args_attack):
    get_output_models = get_output.get_all_features(model=None, device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
                                                    epsilon=args_attack.attacks.epsilon, args=args_attack.attacks)
    return get_output_models


def just_mean(d_grads):
    d_grads = torch.stack([d for d in d_grads])
    return torch.mean(d_grads, dim=0)


def perform_AttGAN(attack, input_imgs, original_imgs, attibutes, attgan_model, attgan_parse, rand_param):
    att_b_list = [attibutes]
    ## No need to attack all attributes
    # for i in range(attgan_parse.n_attrs):
    #     tmp = attibutes.clone()
    #     tmp[:, i] = 1 - tmp[:, i]
    #     tmp = check_attribute_conflict(tmp, attgan_parse.attrs[i], attgan_parse.attrs)
    #     att_b_list.append(tmp)
    # att_b_list = [att_b_list[0]]
    for i, att_b in enumerate(att_b_list):
        att_b_ = (att_b * 2 - 1) * attgan_parse.thres_int
        if i > 0:
            att_b_[..., i - 1] = att_b_[..., i - 1] * attgan_parse.test_int / attgan_parse.thres_int
        with torch.no_grad():
            gen_noattack, no_attack_middle = attgan_model.G(original_imgs, att_b_)
        adv_gen, adv_gen_middle = attack.get_attgan_features(input_imgs, att_b_, attgan_model, rand_param)

    return [gen_noattack, adv_gen], [no_attack_middle[-1], adv_gen_middle[-1]]


def perform_HiSD(attack, input_imgs, original_imgs, reference_img, E_model, F_model, T_model, G_model, EFTG_models, rand_param):
    with torch.no_grad():
        # get the original deepfake images
        c = E_model(original_imgs)
        c_trg = c
        s_trg = F_model(reference_img, 1)
        c_trg = T_model(c_trg, s_trg, 1)
        x_trg = G_model(c_trg)

    adv_x_trg, adv_c = attack.get_hisd_features(input_imgs.cuda(), reference_img, F_model, T_model, G_model, E_model, EFTG_models, rand_param)
    return [x_trg, adv_x_trg], [c, adv_c]


def select_model_to_get_feature_pairs(case, img, ori_imgs, reference, attribute_c, attribute_attgan, attack, stargan_s, atggan_s,
                                      attgan_s, attgan_args, EE, FF, TT, GG, g_models, reconstruct=128, attr_aug=False):
    if attr_aug:
        rand_q = np.random.rand()
    else:
        rand_q = 0
    if case == 0:
        # print('attacking stargan...')
        output_pair, middle_pair = stargan_s.perform_stargan(img, ori_imgs, attribute_c, attack, rand_q)
    elif case == 1:
        # print('attacking attentiongan...')
        output_pair, middle_pair = atggan_s.perform_attentiongan(img, ori_imgs, attribute_c, attack, rand_q)
    elif case == 2:
        # print('attacking AttGan...')
        output_pair, middle_pair = perform_AttGAN(attack, img, ori_imgs, attribute_attgan, attgan_s, attgan_args, rand_q)
    elif case == 3:
        # print('attacking HiSD...')
        output_pair, middle_pair = perform_HiSD(attack, img, ori_imgs, reference, EE, FF, TT, GG, g_models, rand_q)
    else:
        raise NotImplementedError('wrong code!')

    # resize feature outputs
    new_middle_pair = []
    for middle in middle_pair:
        new_middle = torch.nn.functional.interpolate(middle, (reconstruct, reconstruct), mode='bilinear')  # 8, 256, 128, 128
        new_middle_pair.append(new_middle)
    return output_pair, new_middle_pair


def DI(X_in):
    import torch.nn.functional as F

    rnd = np.random.randint(256, 290, size=1)[0]
    h_rem = 290 - rnd
    w_rem = 290 - rnd
    pad_top = np.random.randint(0, h_rem, size=1)[0]
    pad_bottom = h_rem - pad_top
    pad_left = np.random.randint(0, w_rem, size=1)[0]
    pad_right = w_rem - pad_left

    c = np.random.rand(1)
    if c <= 0.5:
        X_out = F.pad(F.interpolate(X_in, size=(rnd, rnd)), (pad_left, pad_right, pad_top, pad_bottom), mode='constant',
                      value=0)
        return F.interpolate(X_out, (256, 256))
    else:
        return F.interpolate(X_in, (256, 256))


def train_attacker():
    args_attack = parse()
    print(args_attack)

    # Init the attacker
    attack_utils = init_get_outputs(args_attack)
    # Init the attacked models
    attack_dataloader, test_dataloader, attgan, attgan_args, stargan_solver, attentiongan_solver, transform, F, T, G, E, reference, gen_models = prepare()

    model_cases = [0, 1, 2, 3]
    import time
    start_time = time.time()

    # Some hyperparameters
    attack_utils.epsilon = 0.05
    reconstruct_feature_size = 32
    iteration_out = 50
    iteration_in = 5
    alpha = 1e-3

    # pgd
    attack_utils.up = attack_utils.up + torch.tensor(np.random.uniform(-attack_utils.epsilon, attack_utils.epsilon, attack_utils.up.shape).astype('float32')).to(attack_utils.device)
    momentum = 0

    for t in range(iteration_out):
        print('%dth iter' % t)

        for idx, (img_a, att_a, c_org) in enumerate(tqdm(attack_dataloader)):
            print('%dth batch' % idx)
            if args_attack.global_settings.num_test is not None and idx * args_attack.global_settings.batch_size == args_attack.global_settings.num_test:
                break
            img_a = img_a.cuda() if args_attack.global_settings.gpu else img_a
            att_a = att_a.cuda() if args_attack.global_settings.gpu else att_a
            att_a = att_a.type(torch.float)

            if do_feature_ensemble:
                # Feature-Ensemble
                for _ in range(iteration_in):
                    attack_utils.up.requires_grad = True
                    new_input = img_a + attack_utils.up
                    middle_pairs = []
                    shuffle(model_cases)
                    for case in model_cases:
                        _, mid_pair = select_model_to_get_feature_pairs(case, DI(new_input), img_a, reference, c_org, att_a,
                                                                        attack_utils, stargan_solver,
                                                                        attentiongan_solver, attgan, attgan_args,
                                                                        E, F, T, G, gen_models, reconstruct_feature_size)
                        middle_pairs.append(mid_pair)

                    clean_middle_from_models = [middle_pairs[p][0] for p in range(len(middle_pairs))]
                    adv_middle_from_models = [middle_pairs[q][1] for q in range(len(middle_pairs))]
                    clean_features_cat = torch.cat(clean_middle_from_models, 1)  # concat all clean features in channel dimention
                    adv_features_cat = torch.cat(adv_middle_from_models, 1)  # concat all adv features in channel dimention

                    loss = -attack_utils.wasserstein_loss(torch.sum(adv_features_cat, 1), torch.sum(clean_features_cat, 1))
                    loss.backward()

                    grad_c = attack_utils.up.grad.clone().to(attack_utils.device)
                    grad_c_hat = grad_c / (torch.mean(torch.abs(grad_c), (1, 2, 3), keepdim=True) + 1e-12)
                    attack_utils.up.grad.zero_()

                    attack_utils.up.data = attack_utils.up.data - alpha * torch.sign(grad_c_hat)
                    attack_utils.up.data = attack_utils.up.data.clamp(-attack_utils.epsilon, attack_utils.epsilon)
                    attack_utils.up = attack_utils.up.detach()

            if do_end_to_end:
                # End-to-End Ensemble
                attack_utils.up.requires_grad = True
                new_new_input = img_a + attack_utils.up
                output_grads = []  # grad_ensemble
                logit_pairs = []  # logit_ensemble
                out_loss = 0  # loss_ensemble
                for case in model_cases:
                    out_pair, _ = select_model_to_get_feature_pairs(case, DI(new_new_input), img_a, reference, c_org, att_a,
                                                                    attack_utils, stargan_solver,
                                                                    attentiongan_solver, attgan, attgan_args,
                                                                    E, F, T, G, gen_models, reconstruct_feature_size)
                    loss_one = -1 * attack_utils.loss_fn(out_pair[0], out_pair[1])
                    if do_grad_ensemble:
                        loss_one.backward()
                        grad_case = attack_utils.up.grad.clone().to(attack_utils.device)
                        grad_case = grad_case / (torch.mean(torch.abs(grad_case), (1, 2, 3), keepdim=True) + 1e-12)
                        output_grads.append(grad_case)
                        attack_utils.up.grad.zero_()
                    elif do_loss_ensemble:
                        out_loss += loss_one
                    elif do_output_ensemble:
                        logit_pairs.append(out_pair)
                if do_grad_ensemble:
                    grad_cout_hat = just_mean(output_grads)
                elif do_loss_ensemble:
                    out_loss.backward()
                    grad_cout_hat = attack_utils.up.grad.clone().to(attack_utils.device)
                    grad_cout_hat = grad_cout_hat / (torch.mean(torch.abs(grad_cout_hat), (1, 2, 3), keepdim=True) + 1e-12)
                elif do_output_ensemble:
                    clean_out = [logit_pairs[p][0] for p in range(len(logit_pairs))]
                    adv_out = [logit_pairs[q][1] for q in range(len(logit_pairs))]
                    clean_cat = torch.cat(clean_out, 1)
                    adv_cat = torch.cat(adv_out, 1)
                    logit_loss = -1 * attack_utils.loss_fn(torch.sum(adv_cat, 1), torch.sum(clean_cat, 1))
                    logit_loss.backward()
                    grad_cout_hat = attack_utils.up.grad.clone().to(attack_utils.device)
                    grad_cout_hat = grad_cout_hat / (torch.mean(torch.abs(grad_cout_hat), (1, 2, 3), keepdim=True) + 1e-12)
                else:
                    raise NotImplementedError('choose one ensemble from grad/loss/logit')

                # MI
                grad_cout_hat = grad_cout_hat + 0.8 * momentum
                momentum = grad_cout_hat

                attack_utils.up.data = attack_utils.up.data - alpha * torch.sign(grad_cout_hat)
                attack_utils.up.data = attack_utils.up.data.clamp(-attack_utils.epsilon, attack_utils.epsilon)
                attack_utils.up = attack_utils.up.detach()

        print('up:', torch.max(attack_utils.up), torch.min(attack_utils.up))

        if batch_evaluate and t % 10 == 0:
            _, _, _, _ = evaluate_multiple_models(args_attack, test_dataloader, attgan, attgan_args, stargan_solver,
                                                  attentiongan_solver,
                                                  transform, F, T, G, E, reference, gen_models, attack_utils,
                                                  max_samples=20)

    end_time = time.time()
    print('cost time:', end_time - start_time)
    torch.save(attack_utils.up, 'pert_FOUND.pt')
    _, _, _, _ = evaluate_multiple_models(args_attack, test_dataloader, attgan, attgan_args, stargan_solver,
                                          attentiongan_solver,
                                          transform, F, T, G, E, reference, gen_models, attack_utils,
                                          max_samples=1000)


if __name__ == "__main__":
    train_attacker()
